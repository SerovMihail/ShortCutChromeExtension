(function() {

    // alert('before click');

    document.activeElement.click();
    
})();



